//4pkt
#include <stdio.h>
#include <stdlib.h>

int i, min=1000, tab2[100], ile_min=0, index[30];

int fun(unsigned int n, int tab[n])
{
    if(n<=0)return 0;

    for(i=0; i<n; i++)
    {
        if(tab[i] < min)min = tab[i];
    }

    printf("TO JEST NAMNIEJSZA WARTOSC: %d\n", min);

    for(i=0; i<n; i++)
    {
        if(tab[i] == min)
        {
            tab2[ile_min]=i;
            //index[ile_min]=i;
            ile_min++;
        }
    }

    printf("TYLE JEST WARTOSCI NAJM: %d\nA to jej index wg polecenia: ", ile_min);
    if(ile_min==1 || ile_min==2)printf("%d", tab2[ile_min-1]);
    if(ile_min>3)printf("%d", tab2[ile_min-2]);

    return 0;
}

int main()
{
    int tab[7]={10, 50, 10, 60, 60, 10, 10};
    fun(7,tab);
    return 0;
}
