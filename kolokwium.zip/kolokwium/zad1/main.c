//5pkt
#include <stdio.h>
#include <stdlib.h>

int x,y,z,w;

int main()
{
    scanf("%d%d%d%d", &x, &y, &z, &w);
    if((x!=y) && (x!=z) && (x!=w) && (z!=y) && (z!=w) && (y!=w))printf("nic");
    else if(x==y && x==z && x==w)printf("kareta");
    else if((x==y && z==w && y!=z)
            || (x==z && y==w && y!=z)
            || (x==w && z==y && x!=y)
            || (y==z && w==x && w!=y)
            || (y==w && z==x && z!=y)
            || (y==x && z==w && z!=y)
            || (z==w && x==y && x!=z))printf("dwie pary");
    else if((x==y && x==z && x!=w)
            || (x==y && x!=z && x==w)
            || (x==y && x==z && x!=w)
            || (y!=z && y==x && y==w)
            || (y==z && y!=x && y==w)
            || (y==z && y==x && y!=w)
            || (z!=x && z==y && z==w)
            || (z==x && z==y && z!=w)
            || (z==x && z!=y && z==w)
            || (w!=x && w==y && w==w)
            || (w==x && w==y && w!=w)
            || (w==x && w!=y && w==w))printf("trojka");
    else printf("para");

    return 0;
}
