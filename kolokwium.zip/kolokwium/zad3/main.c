

//3pkt
#include <stdio.h>
#include <stdlib.h>

int x,i;

int cyfrajednosci(unsigned int n)
{
    for(i=0; (i+n%10!=n); i++);
    n=n-i;
    return n;
}

int main()
{
    int n;
    scanf("%d", &n);
    printf("%d", cyfrajednosci(n));
    return 0;
}
