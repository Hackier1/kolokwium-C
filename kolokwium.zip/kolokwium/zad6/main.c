//3 pkt
#include <stdio.h>
#include <stdlib.h>

int fun(int a, int b, int (*fun1)(int, int))
{
    return fun1(a, b);

}

int fun1(int x, int n)
{
    return x + n;

}

int main()
{
    int (*wsk)(int, int);
    printf("%d", fun(8, 5, *fun1));
}
