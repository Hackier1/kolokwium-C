//3pkt
#include <stdio.h>
#include <stdlib.h>

int x;

int funnk(int n)
{
    if(n==0 || n==1 || n==2)return 1;
        else return (funnk(n-1)+funnk(n-2)+funnk(n-3));
}

int main()
{
    scanf("%d", &x);
    printf("%d", funnk(x));

    return 0;
}
