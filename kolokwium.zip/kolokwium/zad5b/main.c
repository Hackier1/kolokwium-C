//Napisz funkcj�e, otrzymuj�ac�a jako argumenty zmienn�a typu unsigned int oraz wska�znik do zmiennej typu
//unsigned int. Funkcja ma zwraca�c �sredni�a geometryczn�a liczby ca lkowitej z pierwszego argumentu i liczby
//ca lkowitej wskazywanej przez drugi argument.
//4pkt
#include <stdio.h>
#include <stdlib.h>

int f(unsigned int x, unsigned int *y)
{
    printf("%f", sqrt(x * *y));
    return sqrt(x * *y);
}

int main()
{
    int x,y;

    scanf("%d%d", &x, &y);
    printf("%d\n", f(x, &y));
}
