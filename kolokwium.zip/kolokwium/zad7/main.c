//3pkt
#include <stdio.h>
#include <stdlib.h>


int licznik=0, m;
int fun(unsigned int n, int tab[n])
{
    for(m=0; m < n; m++)
    {
        if(m%2==0)
        {
            tab[licznik] = tab[m];
            licznik = licznik + 1;
        }
    }

    for(licznik = licznik - 1; licznik >= 0; licznik--)
    {
        printf("%d\n", tab[licznik]);
    }
}

int main()
{
    int liczby[5] = {5,8,8,7,6};
    fun(5,liczby);

    return 0;
}
