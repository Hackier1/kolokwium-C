//Napisz program, kt�ory spo�sr�od wszystkich ca lkowitych nieujemnych liczb trzycyfrowych odnajdzie t�a kt�ora
//ma najwi�ecej dzielnik�ow. W przypadku gdyby by lo kilka takich liczb wystarczy znale�z�c dowoln�a z nich.
//Wy�swietli�c t�a liczb�e, jej wszystkie dzielniki oraz informacj�e ile ich jest.
//Np. 541 jest liczb�a pierwsz�a, ma tylko dwa dzielniki 1 oraz 541, wi�ec to raczej nie o ni�a chodzi w zadaniu.
//4pkt
#include <stdio.h>
#include <stdlib.h>

int h, i, l, najwieksza=0, najwieksza2=0;
int tab[1000];
int dzielniki[32];

int dzielnik()
{
   for(i=100;i<1000;i++)
   {
       tab[i]=0;
   }
}

int dzielnik2()
{
   for(i=100;i<1000;i++)
   {
       for(l=1; l<i; l++)
       {
            if(i%l==0)tab[i] = tab[i] ++;
       }

   }
}

int dzielnik3()
{
   for(i=100;i<1000;i++)
   {
       if(tab[i]>najwieksza)
       {
            najwieksza=tab[i];
            najwieksza2=i;
       }

   }
   i=i--;
   printf("%d  %d",najwieksza, najwieksza2);
}

int main()
{
    dzielnik();
    dzielnik2();
    dzielnik3();
    for(i=1;i<=najwieksza2;i++)
    {
        if(najwieksza2%i==0)
            {
                dzielniki[h] = i;
                printf("\n%d",dzielniki[h]);
            }
    }
    return 0;
}
